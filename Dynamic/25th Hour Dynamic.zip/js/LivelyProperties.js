console.log("Starting...");

function livelyPropertyListener(name, val) {
  // or switch-case...
  if (name == "property1Class") {
    console.log(val); //43
  } else if (name == "color1Class") {
    console.log(val); //#C0C0C0
  }
}

/* function livelyPropertyListener(name, val) {
  debug.textContent += `Name: ${name} Val: ${val}`;
  switch (name) {
    case "volume":
      console.log(val);
      break;
    case "panel-location":
      console.log(val);
      break;

    default:
      console.error(`Unknown customization option: ${name}`);
      break;
  }
} */

/* {
  "volume": {
    "max": 100,
    "min": 0,
    "tick": 25,
    "text": "Audio volume",
    "type": "slider",
    "value": 43
  },
  "panel-location": {
    "type": "dropdown",
    "value": 1,
    "text": "Settings panel location",
    "items": ["Left", "Right"]
  }
}
 */
